import timeit
import numpy as np 
import pandas as pd 
import progressbar
import os
import cv2
from scipy.ndimage import gaussian_filter
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torchvision import transforms, models
from PIL import Image
from sklearn.metrics import classification_report
start = timeit.default_timer()
print("#########################################################")
file_name = "./tabular_dataset/tabular.csv"
df = pd.read_csv(file_name)
path = './syn_vision_dataset/'
columns = df.columns
if not os.path.exists(path):
    os.makedirs(path)
def normalize_to_range(data):
    min_val = min(data)
    max_val = max(data)
    normalized_data = [(x - min_val) / (max_val - min_val) for x in data]
    return normalized_data
def normalize_to_range(numbers, new_min=0, new_max=1):
    old_min, old_max = min(numbers), max(numbers)
    return [(new_max - new_min) * (num - old_min) / (old_max - old_min) + new_min for num in numbers]
for index, row in sorted(df.iterrows()):
    numbers = row[:].values  
    numbers_norm = normalize_to_range(numbers)    
    feature_map = np.zeros((224, 224))
    center_point = (112, 112)
    radius = 72
    num_points = len(numbers)  
    angles = np.linspace(0, 2 * np.pi, num_points, endpoint=False)    
    polygon_points = [
        (int(center_point[0] + radius * np.cos(angle)),
         int(center_point[1] + radius * np.sin(angle)))
        for angle in angles]
    positions = [center_point] + polygon_points    
    for pos, value in zip(positions, numbers_norm):
        feature_map[pos] = value    
    smoothed_feature_map = gaussian_filter(feature_map, sigma=10)
    smoothed_feature_map = cv2.normalize(smoothed_feature_map, None, 0, 255, cv2.NORM_MINMAX)
    smoothed_feature_map = smoothed_feature_map.astype(np.uint8)    
    feature_map_rgb = cv2.applyColorMap(smoothed_feature_map, cv2.COLORMAP_JET)    
    class_label = int(row[-1])  
    class_folder = path +'/'
    cv2.imwrite(class_folder + str(index).zfill(4) + ".png", feature_map_rgb)
class StudentNetwork(nn.Module):
    def __init__(self, num_classes=10):
        super(StudentNetwork, self).__init__()
        self.backbone = models.mobilenet_v2(pretrained=True)        
        for param in self.backbone.parameters():
            param.requires_grad = False
        self.backbone.classifier[1] = nn.Linear(self.backbone.last_channel, 2)        
    def forward(self, x):
        out = self.backbone(x)        
        return out
def load_checkpoint(model, checkpoint_path='best_model.pth'):
    checkpoint = torch.load(checkpoint_path,map_location=torch.device('cpu'))
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()  
    print("#########################################################")
    print("Checkpoint loaded successfully.")
def preprocess_image(image_path, transform):
    img = Image.open(image_path).convert('RGB')
    img = transform(img).unsqueeze(0)
    return img
def predict_image(model, image_path, transform, device='cpu'):
    img = preprocess_image(image_path, transform).to(device)  # Move image to GPU/CPU
    with torch.no_grad():
        output = model(img)
    _, predicted_class = torch.max(output, 1)
    return predicted_class.item()
def evaluate_folder(model, folder_path, transform, device='cpu'):
    all_preds = []
    for img_name in os.listdir(folder_path):
        img_path = os.path.join(folder_path, img_name)
        print("#########################################################")
        print("Synthetic image saved as: ", test_folder_path+img_name)
        predicted_class = predict_image(model, img_path, transform, device)
        all_preds.append(predicted_class)
    return all_preds
transform = transforms.Compose([
    transforms.Resize((224, 224)), 
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
student_model = StudentNetwork(num_classes=2).cpu()  
load_checkpoint(student_model, checkpoint_path='./ckpt/student_model.pth')  
test_folder_path = './syn_vision_dataset/' 
predicted_labels = evaluate_folder(student_model, test_folder_path, transform, device='cpu')
inp=[]
for column, values in df.items():
    inp.append(column + ": " + str(values[0])) 
print("#########################################################")
print("Input data: ")
for item in inp:
    print(item)
print("#########################################################")
for pred in predicted_labels:    
    if pred==0:
        print("Class Prediction: ", "BAD (Quality <7)")
    else:
        print("Class Prediction: ", "GOOD (7<= Quality <=10)")
stop = timeit.default_timer()
print("#########################################################")
print('Processing Time: ', stop - start, 's') 
